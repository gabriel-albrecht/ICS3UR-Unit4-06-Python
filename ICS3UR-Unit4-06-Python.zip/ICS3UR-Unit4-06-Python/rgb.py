#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program shows all possible RGB colours


def main():
    red = 0
    green = 0
    blue = 0
    for red in range(0, 255):
        for green in range(0, 2):
            for blue in range(0, 2):
                print("RGB({0},{1},{2})".format(red, green, blue))
                blue += 1
            green += 1
        red += 1


if __name__ == "__main__":
    main()
